"use strict";

const TEAM_URLS = {
  cops: "COPS_APP_URL",
  mqa: "MQA_APP_URL",
  channelMarketing: "CHANNEL_MARKETING_APP_URL"
};

document.querySelectorAll("[data-team-url]").forEach(link => {
  link.href = TEAM_URLS[link.dataset.teamUrl];
});
