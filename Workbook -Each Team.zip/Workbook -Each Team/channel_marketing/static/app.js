/******************************************************************
 * Workbook Automation Tool
 * app.js V2
 * Part 1A
 * Globals • DOM Cache • Bootstrap • Initialization
 ******************************************************************/
"use strict";

const RuntimeConfig = {
    enterpriseMode: document.body?.dataset.enterpriseMode === "true",
    autoDownloadEnabled: document.body?.dataset.autoDownloadEnabled !== "false",
    autoUploadEnabled: document.body?.dataset.autoUploadEnabled !== "false"
};

/* ============================================================
   APPLICATION STATE
============================================================ */

const AppState = {

    workbook: null,
    workbookName: "",
    workbookType: "",
    selectedSheet: "",

    selectedSheets: [],

    worksheetSelectionOrder: [],

    monitorId: "",
    monitorTimer: null,
    temporaryWorkbook: null,
    readyHighlightKey: "",

    prompt: {
        offer: "",
        context: "",
        sheet: "",
        final: ""
    },

    dirty: false,

    loading: false,

    workflowStep: 1,

    maskingSummary: [],

    sessionPromptOverrides: {},

    originalSheetPrompts: {},

    promptSafe: false

};

/* ============================================================
   DOM CACHE
============================================================ */

const UI = {

    /* Header */

    projectRef:
        document.getElementById("projectRef"),

    taskNumber:
        document.getElementById("taskNumber"),

    fetchButton:
        document.getElementById("fetchWorkbookBtn"),

    resetWorkspaceButton:
        document.getElementById("resetWorkspaceBtn"),

    manualDownloadPanel:
        document.getElementById("manualDownloadPanel"),

    manualDownloadMessage:
        document.getElementById("manualDownloadMessage"),

    downloadPanelTitle:
        document.getElementById("downloadPanelTitle"),

    expectedWorkbookName:
        document.getElementById("expectedWorkbookName"),

    openTaskButton:
        document.getElementById("openTaskBtn"),

    manualWorkbookInput:
        document.getElementById("manualWorkbookInput"),

    downloadMonitorStatus:
        document.getElementById("downloadMonitorStatus"),

    cancelMonitorButton:
        document.getElementById("cancelMonitorBtn"),

    manualUploadLabel:
        document.getElementById("manualUploadLabel"),

    /* KPI */

    workbookName:
        document.getElementById("workbookName"),

    workbookType:
        document.getElementById("workbookType"),

    workbookSource:
        document.getElementById("workbookSource"),

    sheetCount:
        document.getElementById("sheetCount"),

    piiStatus:
        document.getElementById("piiStatus"),

    aiStatus:
        document.getElementById("aiStatus"),

    /* Prompt Builder */

    sheetSelector:
        document.getElementById("sheetSelector"),

    worksheetDropdownButton:
        document.getElementById("worksheetDropdownButton"),

    worksheetCheckboxList:
        document.getElementById("worksheetCheckboxList"),

    selectAllWorksheetsButton:
        document.getElementById("selectAllWorksheetsBtn"),

    clearAllWorksheetsButton:
        document.getElementById("clearAllWorksheetsBtn"),

    previewSheetButton:
        document.getElementById("previewSheetBtn"),

    worksheetSelectionMessage:
        document.getElementById("worksheetSelectionMessage"),

    offer:
        document.getElementById("offerDescription"),

    workfrontContentFields:
        document.getElementById("workfrontContentFields"),

    context:
        document.getElementById("workbookContext"),

    workbookContentList:
        document.getElementById("workbookContentList"),

    sheetPrompt:
        document.getElementById("sheetPrompt"),

    sheetInstructionSummary:
        document.getElementById("sheetInstructionSummary"),

    openSheetInstructionsButton:
        document.getElementById("openSheetInstructionsBtn"),

    sheetInstructionsCollapse:
        document.getElementById("sheetInstructionsCollapse"),

    sheetInstructionsDetails:
        document.getElementById("sheetInstructionsDetails"),

    sheetHeaderActions:
        document.getElementById("sheetHeaderActions"),

    viewFullSheetInstructionsButton:
        document.getElementById("viewFullSheetInstructionsBtn"),

    sheetTemplateName:
        document.getElementById("sheetTemplateName"),

    sheetWorksheetType:
        document.getElementById("sheetWorksheetType"),

    sheetInstructionsModal:
        document.getElementById("sheetInstructionsModal"),

    sheetInstructionsModalSheetName:
        document.getElementById("sheetInstructionsModalSheetName"),

    sheetInstructionsModalTemplateName:
        document.getElementById("sheetInstructionsModalTemplateName"),

    modalEditSheetInstructionsButton:
        document.getElementById("modalEditSheetInstructionsBtn"),

    copySheetInstructionsButton:
        document.getElementById("copySheetInstructionsBtn"),

    saveSheetInstructionsButton:
        document.getElementById("saveSheetInstructionsBtn"),

    resetSheetInstructionsButton:
        document.getElementById("resetSheetInstructionsBtn"),

    finalPrompt:
        document.getElementById("finalPrompt"),

    /* Preview */

    previewButton:
        document.getElementById("previewPromptBtn"),

    previewArea:
        document.getElementById("previewPrompt"),

    previewModal:
        document.getElementById("promptPreviewModal"),

    copySafetyReminderModal:
        document.getElementById("copySafetyReminderModal"),

    sheetPreviewModal:
        document.getElementById("sheetPreviewModal"),

    sheetPreviewGrid:
        document.getElementById("sheetPreviewGrid"),

    sheetPreviewTabs:
        document.getElementById("sheetPreviewTabs"),

    sheetPreviewWorkbookName:
        document.getElementById("sheetPreviewWorkbookName"),

    sheetPreviewNotice:
        document.getElementById("sheetPreviewNotice"),

    copyButton:
        document.getElementById("copyPromptBtn"),

    copyPreviewButton:
        document.getElementById("copyPreviewBtn"),

    /* Status */

    offerStatus:
        document.getElementById("offerStatus"),

    workbookStatus:
        document.getElementById("workbookStatus"),

    sheetStatus:
        document.getElementById("sheetStatus"),

    promptBuilderActivity:
        document.getElementById("promptBuilderActivity"),

    workbookDetailsStrip:
        document.getElementById("workbookDetailsStrip"),

    sheetSelectorGroup:
        document.getElementById("sheetSelectorGroup"),

    creditCardMaskStatus:
        document.getElementById("creditCardMaskStatus"),

    ssnMaskStatus:
        document.getElementById("ssnMaskStatus"),

    promptSafetyMessage:
        document.getElementById("promptSafetyMessage"),

    promptSafetyIcon:
        document.getElementById("promptSafetyIcon"),

    promptSafetyStatus:
        document.getElementById("promptSafetyStatus"),

    promptSafetyAlert:
        document.getElementById("promptSafetyAlert"),

    generatedPromptStatus:
        document.getElementById("generatedPromptStatus"),

    gptWorkspaceEmpty:
        document.getElementById("gptWorkspaceEmpty"),

    gptIframe:
        document.getElementById("gptIframe"),

    promptReadiness:
        document.getElementById("promptReadiness"),

    temporaryWorkbookAttachment:
        document.getElementById("promptAttachments"),

    temporaryWorkbookName:
        document.getElementById("temporaryWorkbookName"),

    temporaryWorkbookSheets:
        document.getElementById("temporaryWorkbookSheets"),

    temporaryWorkbookSize:
        document.getElementById("temporaryWorkbookSize"),

    generatedPromptFileSize:
        document.getElementById("generatedPromptFileSize"),

    previewPromptAttachmentButton:
        document.getElementById("previewPromptAttachmentBtn"),

    downloadPromptButton:
        document.getElementById("downloadPromptBtn"),

    copyPromptAttachmentButton:
        document.getElementById("copyPromptAttachmentBtn"),

    generatedPromptCard:
        document.querySelector(".generated-prompt-card"),

    maskingSummary:
        document.getElementById("maskingSummary"),

    maskingSummaryCount:
        document.getElementById("maskingSummaryCount"),

    maskingSummaryList:
        document.getElementById("maskingSummaryList"),

    /* Loading */

    loadingOverlay:
        document.getElementById("loadingOverlay"),

    /* Toast */

    liveToast:
        document.getElementById("liveToast")

};

/* ============================================================
   BOOTSTRAP COMPONENTS
============================================================ */

const BootstrapUI = {

    toast: null,

    previewModal: null,

    sheetPreviewModal: null,

    sheetInstructionsModal: null,

    copySafetyReminderModal: null

};

/* ============================================================
   INITIALIZE
============================================================ */

function initializeApplication() {

    initializeBootstrap();

    cacheDefaults();

    registerBaseEvents();

    resetInterface();

    console.log(
        "Workbook Automation Tool Initialized"
    );

}

/* ============================================================
   BOOTSTRAP
============================================================ */

function initializeBootstrap() {

    if (UI.liveToast) {

        BootstrapUI.toast =
            bootstrap.Toast.getOrCreateInstance(
                UI.liveToast
            );

    }

    if (UI.previewModal) {

        BootstrapUI.previewModal =
            bootstrap.Modal.getOrCreateInstance(
                UI.previewModal
            );

    }

}

/* ============================================================
   DEFAULT VALUES
============================================================ */

function cacheDefaults() {

    AppState.workflowStep = 1;

    AppState.loading = false;

    AppState.dirty = false;

}

/* ============================================================
   RESET UI
============================================================ */

function resetInterface() {

    showSheetInstructionsEmptyState();

    UI.workbookDetailsStrip?.classList.add("d-none");

    UI.sheetSelectorGroup?.classList.add("d-none");

    if (UI.previewSheetButton)
        UI.previewSheetButton.disabled = true;

    updateWorkbookFetchStatus(
        "Waiting",
        "secondary"
    );

    if (UI.workbookName)
        UI.workbookName.textContent = "Not Loaded";

    if (UI.workbookType)
        UI.workbookType.textContent = "-";

    if (UI.workbookSource) {

        UI.workbookSource.textContent = "-";
        UI.workbookSource.className =
            "badge bg-secondary";

    }

    if (UI.sheetInstructionsModal) {

        BootstrapUI.sheetInstructionsModal =
            bootstrap.Modal.getOrCreateInstance(
                UI.sheetInstructionsModal
            );

    }

    if (UI.sheetPreviewModal) {

        BootstrapUI.sheetPreviewModal =
            bootstrap.Modal.getOrCreateInstance(
                UI.sheetPreviewModal
            );

    }

    if (UI.copySafetyReminderModal) {

        BootstrapUI.copySafetyReminderModal =
            bootstrap.Modal.getOrCreateInstance(
                UI.copySafetyReminderModal
            );

    }

    document
        .querySelectorAll('[data-bs-toggle="popover"]')
        .forEach(element =>
            bootstrap.Popover.getOrCreateInstance(element)
        );

    if (UI.sheetCount)
        UI.sheetCount.textContent = "0";

    if (UI.aiStatus)
        UI.aiStatus.textContent = "Ready";

    if (UI.piiStatus)
        UI.piiStatus.textContent = "None";

    [
        UI.offer,
        UI.context,
        UI.sheetPrompt,
        UI.finalPrompt
    ].forEach(element => {

        if (!element) return;

        element.value = "";

        element.readOnly = true;

    });

}

/******************************************************************
 * Part 1B
 * Event Registration
 * Workflow
 * Loading
 * Toast
 * Common Helpers
 ******************************************************************/

/* ============================================================
   EVENT REGISTRATION
============================================================ */

function registerBaseEvents() {

    UI.fetchButton?.addEventListener(
        "click",
        fetchWorkbook
    );

    UI.resetWorkspaceButton?.addEventListener(
        "click",
        resetApplication
    );

    UI.previewSheetButton?.addEventListener(
        "click",
        showSheetPreview
    );

    UI.sheetSelector?.addEventListener(
        "change",
        handleSheetSelection
    );

    UI.manualWorkbookInput?.addEventListener(
        "change",
        handleManualWorkbookUpload
    );

    UI.cancelMonitorButton?.addEventListener(
        "click",
        cancelWorkbookMonitoring
    );

    UI.selectAllWorksheetsButton?.addEventListener(
        "click",
        selectAllWorksheets
    );

    UI.clearAllWorksheetsButton?.addEventListener(
        "click",
        clearAllWorksheets
    );

    UI.previewPromptAttachmentButton?.addEventListener(
        "click",
        showPromptPreview
    );

    UI.sheetSelector?.addEventListener(
        "mousedown",
        event => {

            if (
                !UI.sheetSelector.multiple ||
                event.target.tagName !== "OPTION"
            ) {

                return;

            }

            event.preventDefault();
            event.target.selected =
                !event.target.selected;
            handleSheetSelection();

        }
    );
}

/* ============================================================
   WORKFLOW
============================================================ */

function setWorkflowStep(step, pending = false) {

    AppState.workflowStep = step;

    const labels = {
        1: pending ? "Downloading Workbook" : "⏳ Waiting for Workbook",
        2: "Loading Workbook",
        3: "Loading Workbook",
        4: "Building Prompt",
        5: "Review and copy",
        6: "Review and copy"
    };

    updatePromptBuilderActivity(
        labels[step] || "⏳ Waiting for Workbook",
        pending ? "warning" :
            step >= 5 ? "success" : "secondary",
        pending
    );

}

function updatePromptBuilderActivity(
    message,
    color = "secondary",
    pending = false
) {

    if (!UI.promptBuilderActivity) return;

    UI.promptBuilderActivity.className =
        `prompt-builder-activity text-${color} align-self-center`;

    UI.promptBuilderActivity.replaceChildren();

    if (pending) {

        const spinner = document.createElement("i");
        spinner.className =
            "bi bi-arrow-repeat status-spinner me-1";
        spinner.setAttribute("aria-hidden", "true");
        UI.promptBuilderActivity.appendChild(spinner);

    }

    UI.promptBuilderActivity.appendChild(
        document.createTextNode(message)
    );

}

/* ============================================================
   LOADING
============================================================ */

function showLoading(showOverlay = true) {

    AppState.loading = true;

    if (showOverlay) {

        UI.loadingOverlay?.classList.remove("d-none");

    }

}

function hideLoading() {

    AppState.loading = false;

    UI.loadingOverlay?.classList.add("d-none");

}

/* ============================================================
   BUTTON STATE
============================================================ */

function disableFetchButton() {

    if (UI.fetchButton) {

        UI.fetchButton.disabled = true;

        UI.fetchButton.innerHTML = `
            <span class="spinner-border spinner-border-sm me-2"></span>
            Fetching...
        `;

    }

    updateWorkbookFetchStatus(
        "Loading",
        "warning",
        true
    );

}

function enableFetchButton() {

    if (UI.fetchButton) {

        UI.fetchButton.disabled = false;

        UI.fetchButton.innerHTML = `
            <i class="bi bi-cloud-download me-2"></i>
            Fetch Workbook
        `;

    }

}

function updateWorkbookFetchStatus(
    message,
    color,
    pending = false
) {

    if (!UI.workbookFetchStatus) return;

    UI.workbookFetchStatus.className =
        `workbook-fetch-status text-${color}`;

    UI.workbookFetchStatus.replaceChildren();

    if (pending) {

        const spinner = document.createElement("i");
        spinner.className =
            "bi bi-arrow-repeat status-spinner me-1";
        UI.workbookFetchStatus.appendChild(spinner);

    }

    else {

        const icon =
            color === "success" ? "🟢 " :
                color === "danger" ? "🔴 " : "⚪ ";

        UI.workbookFetchStatus.appendChild(
            document.createTextNode(icon)
        );

    }

    UI.workbookFetchStatus.appendChild(
        document.createTextNode(message)
    );

}

/* ============================================================
   TOAST
============================================================ */

function showToast(message) {

    if (!BootstrapUI.toast) {

        alert(message);

        return;

    }

    const body =
        UI.liveToast.querySelector(".toast-body");

    if (body) {

        body.innerHTML = `
            <i class="bi bi-check-circle-fill me-2"></i>
            ${message}
        `;

    }

    BootstrapUI.toast.show();

}

/* ============================================================
   STATUS BADGES
============================================================ */

function setBadge(element, text, color, pending = false) {

    if (!element) return;

    element.className = `badge bg-${color}`;
    element.replaceChildren();

    if (pending) {

        const spinner = document.createElement("i");
        spinner.className =
            "bi bi-arrow-repeat status-spinner me-1";
        spinner.setAttribute("aria-hidden", "true");
        element.appendChild(spinner);

    }

    element.appendChild(
        document.createTextNode(text)
    );

}

function updatePromptStatus(section, state) {

    const map = {

        offer: UI.offerStatus,

        workbook: UI.workbookStatus,

        sheet: UI.sheetStatus

    };

    const badge = map[section];

    if (!badge) return;

    const iconStates = {
        ready: ["success", "Ready"],
        editing: ["warning", "Editing"],
        waiting: ["secondary", "Waiting"],
        pending: ["warning", "Loading"],
        error: ["danger", "Error"]
    };

    const [iconColor, iconLabel] =
        iconStates[state] || iconStates.waiting;

    badge.className =
        `section-status text-${iconColor}`;
    badge.textContent = "●";
    badge.title = iconLabel;
    badge.setAttribute("aria-label", iconLabel);

    return;

    switch (state) {

        case "ready":

            setBadge(
                badge,
                "🟢 Ready",
                "success"
            );

            break;

        case "editing":

            setBadge(
                badge,
                "Editing",
                "warning"
            );

            break;

        case "waiting":

            setBadge(
                badge,
                "🟡 Waiting",
                "warning"
            );

            break;

        case "pending":

            setBadge(
                badge,
                "Pending",
                "primary",
                true
            );

            break;

        default:

            setBadge(
                badge,
                state,
                "primary"
            );

    }

}

/* ============================================================
   AI STATUS
============================================================ */

function updateAIStatus(message) {

    if (!UI.aiStatus) return;

    const normalized =
        String(message).toLowerCase();

    const pending =
        normalized.endsWith("...") ||
        /(searching|scanning|loading|processing|downloading)/.test(normalized);

    const complete =
        /(ready|downloaded|loaded|copied|complete|safe)/.test(normalized);

    const failed =
        /(error|failed|unsafe)/.test(normalized);

    setBadge(
        UI.aiStatus,
        message,
        failed ? "danger" :
            complete ? "success" :
                pending ? "warning" : "secondary",
        pending
    );

}

/* ============================================================
   PII STATUS
============================================================ */

function updatePIIBadge(hasPII, count = 0) {

    if (!UI.piiStatus) return;

    if (hasPII) {

        UI.piiStatus.className =
            "badge bg-danger";

        UI.piiStatus.textContent =
            `${count} Found`;

    }

    else {

        UI.piiStatus.className =
            "badge bg-success";

        UI.piiStatus.textContent =
            "None";

    }

}

/* ============================================================
   SAFE VALUE
============================================================ */

function safeText(value, fallback = "-") {

    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {

        return fallback;

    }

    return value;

}

/******************************************************************
 * Part 1C
 * Clipboard
 * Prompt Preview
 * Local Storage
 * Utility Functions
 * Reset Helpers
 ******************************************************************/

/* ============================================================
   CLIPBOARD
============================================================ */

async function copyToClipboard(text, successMessage = "Copied successfully.") {

    try {

        if (!text) {

            showToast("Nothing to copy.");

            return false;

        }

        await navigator.clipboard.writeText(text);

        if (successMessage)
            showToast(successMessage);

        return true;

    }

    catch (error) {

        console.error(error);

        alert("Unable to copy.");

        return false;

    }

}

/* ============================================================
   PREVIEW MODAL
============================================================ */

function updatePreview() {

    if (!UI.previewArea || !UI.finalPrompt)
        return;

    UI.previewArea.value =
        UI.finalPrompt.value;

}

function openPreview() {

    updatePreview();

    BootstrapUI.previewModal?.show();

}

function closePreview() {

    BootstrapUI.previewModal?.hide();

}

/* ============================================================
   CHARACTER COUNT
============================================================ */

function characterCount(text) {

    return text
        ? text.length
        : 0;

}

function wordCount(text) {

    if (!text) return 0;

    return text
        .trim()
        .split(/\s+/)
        .filter(Boolean)
        .length;

}

/* ============================================================
   LOCAL STORAGE
============================================================ */

const STORAGE_KEY =
    "WorkbookAutomationDraft";

function saveDraft() {

    try {

        const draft = {

            offer:
                UI.offer?.value || "",

            context:
                UI.context?.value || "",

            sheet:
                UI.sheetPrompt?.value || "",

            prompt:
                UI.finalPrompt?.value || "",

            selectedSheet:
                AppState.selectedSheet,

            selectedSheets:
                AppState.selectedSheets,

            savedOn:
                new Date().toISOString()

        };

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(draft)
        );

    }

    catch (error) {

        console.warn(error);

    }

}

function loadDraft() {

    try {

        const draft =
            JSON.parse(
                localStorage.getItem(STORAGE_KEY)
            );

        if (!draft) return;

        if (UI.offer)
            UI.offer.value =
                draft.offer || "";

        if (UI.context)
            UI.context.value =
                draft.context || "";

        if (UI.sheetPrompt)
            UI.sheetPrompt.value =
                draft.sheet || "";

        if (UI.finalPrompt)
            UI.finalPrompt.value =
                draft.prompt || "";

    }

    catch (error) {

        console.warn(error);

    }

}

function clearDraft() {

    localStorage.removeItem(
        STORAGE_KEY
    );

}

/* ============================================================
   RESET PROMPT BUILDER
============================================================ */

function clearPromptBuilder() {

    [

        UI.offer,

        UI.context,

        UI.sheetPrompt,

        UI.finalPrompt

    ].forEach(element => {

        if (element)
            element.value = "";

    });

    updatePromptStatus(
        "offer",
        "waiting"
    );

    updatePromptStatus(
        "workbook",
        "waiting"
    );

    updatePromptStatus(
        "sheet",
        "waiting"
    );

}

/* ============================================================
   RESET SHEET LIST
============================================================ */

function resetSheetSelector() {

    if (!UI.sheetSelector)
        return;

    UI.sheetSelector.replaceChildren();
    UI.worksheetCheckboxList?.replaceChildren();
    if (UI.worksheetDropdownButton)
        UI.worksheetDropdownButton.textContent =
            "Select worksheets";

}

/* ============================================================
   DATE
============================================================ */

function today() {

    return new Date()
        .toLocaleDateString();

}

/* ============================================================
   DELAY
============================================================ */

function delay(ms) {

    return new Promise(resolve => {

        setTimeout(resolve, ms);

    });

}

/* ============================================================
   DEBUG LOGGER
============================================================ */

function log(...message) {

    console.log(
        "[Workbook Tool]",
        ...message
    );

}

/* ============================================================
   INITIAL STATE
============================================================ */

setWorkflowStep(1);

updatePromptStatus(
    "offer",
    "waiting"
);

updatePromptStatus(
    "workbook",
    "waiting"
);

updatePromptStatus(
    "sheet",
    "waiting"
);

log("Globals Loaded");

/******************************************************************
 * END OF 01_globals.js
 ******************************************************************/

/******************************************************************
 * 02_fetchWorkbook.js
 * Part 2A
 * Workbook Fetch API
 ******************************************************************/

/* ============================================================
   FETCH WORKBOOK
============================================================ */

async function fetchWorkbook() {

    const projectReference =
        UI.projectRef?.value.trim();

    const taskNumber =
        UI.taskNumber?.value.trim();

    if (!projectReference) {

        showToast("Please enter Project Reference.");

        UI.projectRef?.focus();

        return;

    }

    if (!taskNumber) {

        showToast("Please enter Task Number.");

        UI.taskNumber?.focus();

        return;

    }

    let fallbackTaskUrl = "";
    let fallbackFilename = "";

    try {

        endWorkbookSession();
        disableFetchButton();

        showLoading();

        clearGeneratedPrompt();

        resetPromptSafety();

        setPromptSafetyState("scanning");

        UI.workbookDetailsStrip?.classList.add("d-none");

        UI.sheetSelectorGroup?.classList.add("d-none");

        setWorkflowStep(1, true);

        updatePromptStatus("offer", "pending");

        updatePromptStatus("workbook", "pending");

        updatePromptStatus("sheet", "pending");

        updateAIStatus("Searching Project...");

        updatePromptBuilderActivity(
            "Searching for workbook...",
            "warning",
            true
        );

        updateWorkbookFetchStatus(
            "Searching",
            "warning",
            true
        );

        UI.manualDownloadPanel?.classList.add(
            "d-none"
        );

        const lookupResponse = await fetch(
            "/lookup_workbook",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    project_reference: projectReference,
                    task_number: taskNumber
                })
            }
        );

        const lookup =
            await lookupResponse.json()
                .catch(() => ({}));

        fallbackTaskUrl = lookup.task_url || "";
        fallbackFilename = lookup.filename || "";

        if (!lookupResponse.ok) {

            throw new Error(
                lookup.error ||
                "Unable to search for the workbook."
            );

        }

        if (lookup.status === "manual_required") {

            showManualDownload(
                lookup.message,
                lookup.task_url,
                lookup.filename
            );

            hideLoading();
            enableFetchButton();
            return;

        }

        if (RuntimeConfig.enterpriseMode) {

            if (RuntimeConfig.autoDownloadEnabled && lookup.workbook_url)
                window.open(lookup.workbook_url, "_blank", "noopener");

            showManualDownload(
                "The workbook download was opened in your browser. Upload the downloaded workbook manually to continue.",
                lookup.task_url,
                lookup.filename
            );

            hideLoading();
            enableFetchButton();
            return;

        }

        updatePromptBuilderActivity(
            "Downloading workbook...",
            "warning",
            true
        );

        updateWorkbookFetchStatus(
            "Downloading",
            "warning",
            true
        );

        const response = await fetch(
            "/fetch_workbook",
            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify({

                    project_reference:
                        projectReference,

                    task_number:
                        taskNumber

                })

            }
        );

        if (!response.ok) {

            const error =
                await response.json()
                    .catch(() => ({}));

            throw new Error(

                error.error ||

                "Unable to fetch workbook."

            );

        }

        const data =
            await response.json();

        if (data.status === "manual_required") {

            setPromptSafetyState("waiting");

            showManualDownload(
                data.message,
                data.task_url,
                data.expected_filename
            );

            hideLoading();
            enableFetchButton();
            return;

        }

        if (data.status === "monitor_required") {

            showManualDownload(
                data.message,
                data.task_url,
                data.expected_filename,
                false
            );

            hideLoading();
            enableFetchButton();
            return;

        }

        updatePromptBuilderActivity(
            "Loading workbook...",
            "warning",
            true
        );

        updateWorkbookFetchStatus(
            "Loading",
            "warning",
            true
        );

        AppState.workbook =
            data;

        setWorkflowStep(2, true);

        updateAIStatus(
            "Workbook Downloaded"
        );

        loadWorkbook(data);

    }

    catch (error) {

        console.error(error);

        setPromptSafetyState("waiting");

        setWorkflowStep(1);

        updatePromptBuilderActivity(
            "Error Loading Workbook",
            "danger"
        );

        updateWorkbookFetchStatus(
            "Error",
            "danger"
        );

        updatePromptStatus("offer", "waiting");

        updatePromptStatus("workbook", "waiting");

        updatePromptStatus("sheet", "waiting");

        updateAIStatus("Error");

        hideLoading();

        enableFetchButton();

        if (RuntimeConfig.enterpriseMode) {
            showManualDownload(
                "Workbook could not be downloaded automatically. Please open the Workfront task, download the latest workbook manually, and upload it here.",
                fallbackTaskUrl,
                fallbackFilename
            );
        }

        showToast(error.message);

    }

}

function showManualDownload(
    message,
    taskUrl,
    expectedFilename,
    manualRequired = true
) {

    if (UI.downloadPanelTitle)
        UI.downloadPanelTitle.textContent =
            manualRequired
                ? "Manual download required"
                : "Workbook download started";

    if (UI.manualDownloadMessage) {

        UI.manualDownloadMessage.textContent =
            message ||
            "Workbook download link not found. Please download the workbook manually using the task link below.";

    }

    if (UI.expectedWorkbookName) {

        UI.expectedWorkbookName.textContent =
            expectedFilename
                ? `Expected workbook: ${expectedFilename}`
                : "";

        UI.expectedWorkbookName.classList.toggle(
            "d-none",
            !expectedFilename
        );

    }

    if (UI.openTaskButton) {

        UI.openTaskButton.href =
            taskUrl || "#";
        UI.openTaskButton.classList.toggle(
            "d-none",
            !taskUrl
        );

    }

    UI.manualDownloadPanel?.classList.remove(
        "d-none"
    );

    updatePromptBuilderActivity(
        "Manual download required",
        "danger"
    );

    updateWorkbookFetchStatus(
        "Manual",
        "danger"
    );

    updateAIStatus("Manual Download Required");

    UI.manualUploadLabel?.classList.toggle(
        "d-none",
        RuntimeConfig.autoUploadEnabled
    );

    if (RuntimeConfig.autoUploadEnabled) {
        startWorkbookMonitoring(expectedFilename);
    }
    else {
        updateMonitorStatus(
            "Upload the downloaded workbook to continue.",
            "primary"
        );
    }

}

async function startWorkbookMonitoring(expectedFilename) {

    await cancelWorkbookMonitoring(false);

    updateMonitorStatus("Monitoring Downloads folder...", "warning", true);

    try {

        const response = await fetch(
            "/monitor_workbook/start",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    project_reference:
                        UI.projectRef?.value.trim() || "",
                    task_number:
                        UI.taskNumber?.value.trim() || "",
                    expected_filename:
                        expectedFilename || ""
                })
            }
        );
        const result = await response.json();
        if (!response.ok)
            throw new Error(result.error || "Unable to start folder monitoring.");

        AppState.monitorId = result.monitor_id;
        updateMonitorStatus(
            `Monitoring Downloads folder: ${result.directory}`,
            "warning",
            true
        );
        AppState.monitorTimer = window.setInterval(
            pollWorkbookMonitoring,
            1500
        );

    }
    catch (error) {

        updateMonitorStatus(error.message, "danger");
        UI.manualUploadLabel?.classList.remove("d-none");

    }

}

async function pollWorkbookMonitoring() {

    if (!AppState.monitorId) return;

    try {

        const response = await fetch(
            "/monitor_workbook/poll",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    monitor_id: AppState.monitorId
                })
            }
        );
        const result = await response.json();
        if (!response.ok)
            throw new Error(result.error || "Folder monitoring failed.");

        updateMonitorStatus(
            result.message || "Waiting for workbook download...",
            result.status === "ready" ? "success" : "warning",
            result.status === "monitoring"
        );

        if (result.status === "ready") {

            stopMonitorTimer();
            AppState.workbook = result;
            updatePromptBuilderActivity(
                "Workbook uploaded successfully.",
                "success"
            );
            updateAIStatus("Workbook Uploaded");
            loadWorkbook(result);

        }
        else if (
            result.status === "timeout" ||
            result.status === "cancelled"
        ) {

            stopMonitorTimer();
            UI.manualUploadLabel?.classList.remove("d-none");

        }

    }
    catch (error) {

        stopMonitorTimer();
        updateMonitorStatus(error.message, "danger");
        UI.manualUploadLabel?.classList.remove("d-none");

    }

}

async function cancelWorkbookMonitoring(notifyServer = true) {

    const monitorId = AppState.monitorId;
    stopMonitorTimer();

    if (notifyServer && monitorId) {

        await fetch(
            "/monitor_workbook/cancel",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    monitor_id: monitorId
                })
            }
        ).catch(() => {});
        updateMonitorStatus(
            "Workbook monitoring cancelled.",
            "secondary"
        );
        UI.manualUploadLabel?.classList.remove("d-none");

    }

}

function stopMonitorTimer() {

    if (AppState.monitorTimer)
        window.clearInterval(AppState.monitorTimer);
    AppState.monitorTimer = null;
    AppState.monitorId = "";

}

function updateMonitorStatus(message, color, pending = false) {

    if (!UI.downloadMonitorStatus) return;
    UI.downloadMonitorStatus.className =
        `download-monitor-status mt-2 text-${color}`;
    UI.downloadMonitorStatus.replaceChildren();
    if (pending) {

        const spinner = document.createElement("span");
        spinner.className =
            "spinner-border spinner-border-sm me-2";
        UI.downloadMonitorStatus.appendChild(spinner);

    }
    UI.downloadMonitorStatus.appendChild(
        document.createTextNode(message)
    );

}

async function handleManualWorkbookUpload(event) {

    const file = event.target.files?.[0];
    if (!file) return;

    await cancelWorkbookMonitoring();

    const form = new FormData();
    form.append("workbook", file);
    form.append(
        "project_reference",
        UI.projectRef?.value.trim() || ""
    );
    form.append(
        "task_number",
        UI.taskNumber?.value.trim() || ""
    );

    try {

        setPromptSafetyState("scanning");

        updatePromptBuilderActivity(
            "Workbook detected and uploading...",
            "warning",
            true
        );

        updateWorkbookFetchStatus(
            "Uploading",
            "warning",
            true
        );

        const response = await fetch(
            "/upload_workbook",
            {
                method: "POST",
                body: form
            }
        );

        const data =
            await response.json()
                .catch(() => ({}));

        if (!response.ok) {

            throw new Error(
                data.error ||
                "Unable to upload the workbook."
            );

        }

        updatePromptBuilderActivity(
            "Loading workbook...",
            "warning",
            true
        );

        updateWorkbookFetchStatus(
            "Loading",
            "warning",
            true
        );

        AppState.workbook = data;
        UI.manualDownloadPanel?.classList.add(
            "d-none"
        );
        event.target.value = "";
        loadWorkbook(data);
        showToast(
            "Workbook detected and uploaded."
        );

    }

    catch (error) {

        console.error(error);
        setPromptSafetyState(
            AppState.workbook ? "complete" : "waiting"
        );
        updatePromptBuilderActivity(
            "Workbook upload failed",
            "danger"
        );
        updateWorkbookFetchStatus(
            "Error",
            "danger"
        );
        showToast(error.message);

    }

}

/* ============================================================
   LOAD WORKBOOK
============================================================ */

function loadWorkbook(data) {

    setPromptSafetyState("scanning");

    AppState.workbookName =
        data.workbook_name || "";

    AppState.workbookType =
        data.workbook_type || "";

    UI.workbookName.textContent =
        safeText(data.workbook_name);

    UI.workbookType.textContent =
        safeText(data.workbook_type);

    if (UI.workbookSource) {

        const manual =
            data.upload_source === "manual";

        UI.workbookSource.className =
            `badge bg-${manual ? "primary" : "success"}`;

        UI.workbookSource.textContent =
            manual
                ? "Manual Upload 📤"
                : "Auto Downloaded ✅";

        UI.workbookSource.title =
            manual
                ? "Manual Upload"
                : "Auto Downloaded";

    }

    UI.sheetCount.textContent =
        data.sheet_count || 0;

    updatePIIBadge(

        data.has_pii || false,

        data.pii_count || 0

    );

    populateSheets(

        data.sheets || []

    );

    UI.workbookDetailsStrip?.classList.remove("d-none");

    UI.sheetSelectorGroup?.classList.remove("d-none");

    if (UI.previewSheetButton)
        UI.previewSheetButton.disabled = false;

    enablePromptBuilder();

    setWorkflowStep(3, true);

    loadDefaultSheet();

    updateAIStatus(

        "Workbook Loaded"

    );

    hideLoading();

    enableFetchButton();

    updateWorkbookFetchStatus(
        "Ready",
        "success"
    );

    showToast(

        "Workbook loaded successfully."

    );

}

/******************************************************************
 * Part 2B
 * Sheet Loader
 * Prompt Builder Population
 ******************************************************************/

/* ============================================================
   POPULATE SHEET DROPDOWN
============================================================ */

function populateSheets(sheetList) {

    resetSheetSelector();
    AppState.worksheetSelectionOrder = [];
    UI.worksheetCheckboxList?.replaceChildren();

    if (!Array.isArray(sheetList))
        return;

    sheetList.forEach(sheet => {

        const option =
            document.createElement("option");

        option.value = sheet;

        option.textContent = sheet;

        UI.sheetSelector.appendChild(option);

        const item = document.createElement("label");
        item.className = "worksheet-checkbox-item";

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.className = "form-check-input";
        checkbox.value = sheet;
        checkbox.addEventListener("change", () => {

            option.selected = checkbox.checked;
            handleSheetSelection();

        });

        const name = document.createElement("span");
        name.textContent = sheet;
        item.append(checkbox, name);
        UI.worksheetCheckboxList?.appendChild(item);

    });

}

function syncWorksheetDropdown() {

    const selected = AppState.selectedSheets;

    if (UI.worksheetDropdownButton) {

        UI.worksheetDropdownButton.textContent =
            selected.length === 0
                ? "Select worksheets"
                : selected.length <= 2
                    ? selected.join(", ")
                    : `${selected.length} Sheets Selected`;

    }

    UI.worksheetCheckboxList
        ?.querySelectorAll('input[type="checkbox"]')
        .forEach(checkbox => {

            checkbox.checked =
                selected.includes(checkbox.value);

        });

}

function selectAllWorksheets() {

    Array.from(UI.sheetSelector.options)
        .forEach(option => {

            option.selected = true;

        });
    AppState.worksheetSelectionOrder =
        Array.from(UI.sheetSelector.options)
            .map(option => option.value);
    handleSheetSelection();

}

function clearAllWorksheets() {

    Array.from(UI.sheetSelector.options)
        .forEach(option => {

            option.selected = false;

        });
    AppState.worksheetSelectionOrder = [];
    handleSheetSelection();

}

/* ============================================================
   SHEET CHANGED
============================================================ */

function handleSheetSelection() {

    const currentlySelected =
        Array.from(
            UI.sheetSelector.selectedOptions
        ).map(option => option.value);

    const selectedSet =
        new Set(currentlySelected);

    const retainedSelectionOrder =
        AppState.worksheetSelectionOrder.filter(
            name => selectedSet.has(name)
        );

    currentlySelected.forEach(name => {

        if (!retainedSelectionOrder.includes(name))
            retainedSelectionOrder.push(name);

    });

    AppState.worksheetSelectionOrder =
        retainedSelectionOrder;

    const sheetNames =
        [...AppState.worksheetSelectionOrder];

    if (!sheetNames.length) {

        AppState.selectedSheet = "";
        AppState.selectedSheets = [];
        AppState.worksheetSelectionOrder = [];
        UI.worksheetSelectionMessage?.classList.remove(
            "d-none"
        );
        if (UI.previewSheetButton)
            UI.previewSheetButton.disabled = true;
        syncWorksheetDropdown();
        renderWorkbookContent([]);
        clearTemporaryWorkbookAttachment();
        clearPromptBuilder();
        clearGeneratedPrompt();
        showSheetInstructionsEmptyState(
            "No worksheet selected",
            "Select a worksheet to load its validation template."
        );
        updatePromptBuilderActivity(
            "Select at least one worksheet",
            "secondary"
        );
        return;

    }

    UI.worksheetSelectionMessage?.classList.add("d-none");
    if (UI.previewSheetButton)
        UI.previewSheetButton.disabled = false;

    AppState.selectedSheet =
        sheetNames[0];

    AppState.selectedSheets =
        sheetNames;
    syncWorksheetDropdown();
    renderWorkbookContent(sheetNames);

    setWorkflowStep(4, true);

    updateAIStatus(
        "Loading Sheet..."
    );

    loadSelectedSheets(sheetNames);

}

function renderWorkbookContent(sheetNames) {

    if (!UI.workbookContentList) return;
    UI.workbookContentList.replaceChildren();

    sheetNames.forEach(name => {

        const row = document.createElement("div");
        row.className = "workbook-content-item";

        const label = document.createElement("span");
        label.innerHTML =
            '<i class="bi bi-file-earmark-spreadsheet me-2"></i>';
        label.appendChild(document.createTextNode(name));

        const preview = document.createElement("button");
        preview.type = "button";
        preview.className = "btn btn-outline-primary btn-sm";
        preview.innerHTML =
            '<i class="bi bi-eye me-1"></i>Preview';
        preview.addEventListener(
            "click",
            () => {

                renderSheetPreview(
                    name,
                    [...AppState.selectedSheets]
                );
                BootstrapUI.sheetPreviewModal?.show();

            }
        );

        row.append(label, preview);
        UI.workbookContentList.appendChild(row);

    });

}

function showSheetPreview() {

    if (!AppState.workbook || !AppState.selectedSheet) {

        showToast("Select a worksheet to preview.");
        return;

    }

    renderSheetPreview(AppState.selectedSheet);
    BootstrapUI.sheetPreviewModal?.show();

}

function showSelectedWorkbookPreview() {

    const selectedSheets =
        [...AppState.selectedSheets];

    if (!selectedSheets.length) {

        showToast("Select at least one worksheet to preview.");
        return;

    }

    renderSheetPreview(
        selectedSheets[0],
        selectedSheets
    );
    BootstrapUI.sheetPreviewModal?.show();

}

function renderSheetPreview(sheetName, availableSheets = null) {

    const sheet =
        AppState.workbook?.sheet_data?.[sheetName];

    if (!sheet || !UI.sheetPreviewGrid) return;

    UI.sheetPreviewWorkbookName.textContent =
        AppState.workbookName || "";
    UI.sheetPreviewGrid.replaceChildren();

    const rows =
        Array.isArray(sheet.preview_rows)
            ? sheet.preview_rows
            : [];
    const layout = sheet.preview_layout || {};
    const columnCount = rows.reduce(
        (maximum, row) =>
            Math.max(maximum, Array.isArray(row) ? row.length : 0),
        0
    );

    const table = document.createElement("table");
    table.className = "sheet-preview-table";
    table.classList.toggle(
        "sheet-preview-no-gridlines",
        layout.show_gridlines === false
    );

    const columnGroup = document.createElement("colgroup");
    const rowHeaderColumn = document.createElement("col");
    rowHeaderColumn.style.width = "48px";
    columnGroup.appendChild(rowHeaderColumn);
    for (let column = 0; column < columnCount; column += 1) {
        const columnElement = document.createElement("col");
        const excelWidth = Number(layout.column_widths?.[column] || 13);
        columnElement.style.width = `${Math.max(24, Math.round(excelWidth * 7 + 5))}px`;
        columnGroup.appendChild(columnElement);
    }
    table.appendChild(columnGroup);

    const head = document.createElement("thead");
    const headingRow = document.createElement("tr");
    const corner = document.createElement("th");
    corner.className = "sheet-row-heading sheet-corner";
    headingRow.appendChild(corner);

    for (let column = 0; column < columnCount; column += 1) {

        const heading = document.createElement("th");
        heading.textContent = excelColumnName(column);
        headingRow.appendChild(heading);

    }

    head.appendChild(headingRow);
    table.appendChild(head);

    const body = document.createElement("tbody");
    const mergedAnchors = new Map();
    const mergedCovered = new Set();
    (layout.merged_ranges || []).forEach(range => {
        const anchor = `${range.min_row}:${range.min_col}`;
        mergedAnchors.set(anchor, {
            rowspan: range.max_row - range.min_row + 1,
            colspan: range.max_col - range.min_col + 1
        });
        for (let row = range.min_row; row <= range.max_row; row += 1) {
            for (let column = range.min_col; column <= range.max_col; column += 1) {
                if (`${row}:${column}` !== anchor)
                    mergedCovered.add(`${row}:${column}`);
            }
        }
    });

    rows.forEach((row, rowIndex) => {

        const tableRow = document.createElement("tr");
        const rowHeight = Number(layout.row_heights?.[rowIndex]);
        if (rowHeight)
            tableRow.style.height = `${Math.round(rowHeight * 4 / 3)}px`;
        const rowHeading = document.createElement("th");
        rowHeading.className = "sheet-row-heading";
        rowHeading.textContent = String(rowIndex + 1);
        tableRow.appendChild(rowHeading);

        for (let column = 0; column < columnCount; column += 1) {

            const coordinate = `${rowIndex + 1}:${column + 1}`;
            if (mergedCovered.has(coordinate)) continue;

            const cell = document.createElement("td");
            const cellData = row[column];
            const value = cellData && typeof cellData === "object"
                ? cellData.value ?? ""
                : cellData ?? "";
            cell.textContent = value;
            cell.title = value;
            applyPreviewCellStyle(
                cell,
                layout.styles?.[cellData?.style_id] || {}
            );
            const merge = mergedAnchors.get(coordinate);
            if (merge) {
                cell.rowSpan = merge.rowspan;
                cell.colSpan = merge.colspan;
            }
            tableRow.appendChild(cell);

        }

        body.appendChild(tableRow);

    });

    table.appendChild(body);
    UI.sheetPreviewGrid.appendChild(table);

    UI.sheetPreviewNotice?.classList.toggle(
        "d-none",
        !sheet.preview_truncated
    );
    if (sheet.preview_truncated && UI.sheetPreviewNotice) {

        UI.sheetPreviewNotice.textContent =
            "Preview is limited to the first 5,000 rows and 200 columns.";

    }

    renderSheetPreviewTabs(
        sheetName,
        availableSheets
    );

}

function applyPreviewCellStyle(cell, style) {

    if (style.fill) cell.style.backgroundColor = style.fill;
    if (style.font?.name) cell.style.fontFamily = style.font.name;
    if (style.font?.size) cell.style.fontSize = `${style.font.size}pt`;
    if (style.font?.bold) cell.style.fontWeight = "700";
    if (style.font?.italic) cell.style.fontStyle = "italic";
    if (style.font?.underline) cell.style.textDecoration = "underline";
    if (style.font?.color) cell.style.color = style.font.color;
    if (style.alignment?.horizontal)
        cell.style.textAlign = style.alignment.horizontal === "general"
            ? "left"
            : style.alignment.horizontal;
    if (style.alignment?.vertical)
        cell.style.verticalAlign = style.alignment.vertical;
    if (style.alignment?.wrap_text) {
        cell.style.whiteSpace = "pre-wrap";
        cell.style.textOverflow = "clip";
    }

    const borderStyles = {
        thin: "1px solid", medium: "2px solid", thick: "3px solid",
        dashed: "1px dashed", dotted: "1px dotted", double: "3px double",
        mediumDashed: "2px dashed", dashDot: "1px dashed",
        mediumDashDot: "2px dashed", dashDotDot: "1px dashed",
        mediumDashDotDot: "2px dashed", hair: "1px dotted"
    };
    Object.entries(style.borders || {}).forEach(([edge, border]) => {
        const declaration = borderStyles[border.style] || "1px solid";
        cell.style[`border${edge[0].toUpperCase()}${edge.slice(1)}`] =
            `${declaration} ${border.color || "#000"}`;
    });

}

function renderSheetPreviewTabs(
    activeSheet,
    availableSheets = null
) {

    if (!UI.sheetPreviewTabs) return;
    UI.sheetPreviewTabs.replaceChildren();

    const sheetNames =
        availableSheets ||
        AppState.workbook?.sheets ||
        [];

    sheetNames.forEach(sheetName => {

        const tab = document.createElement("button");
        tab.type = "button";
        tab.className =
            `sheet-preview-tab${sheetName === activeSheet ? " active" : ""}`;
        tab.textContent = sheetName;
        tab.setAttribute(
            "aria-selected",
            String(sheetName === activeSheet)
        );
        tab.addEventListener("click", () => {

            renderSheetPreview(
                sheetName,
                sheetNames
            );

        });
        UI.sheetPreviewTabs.appendChild(tab);

    });

}

function excelColumnName(index) {

    let value = index + 1;
    let name = "";

    while (value > 0) {

        value -= 1;
        name =
            String.fromCharCode(65 + (value % 26)) + name;
        value = Math.floor(value / 26);

    }

    return name;

}

async function loadSelectedSheets(sheetNames) {

    const selected = sheetNames
        .map(name => ({
            name,
            data: AppState.workbook
                ?.sheet_data?.[name]
        }))
        .filter(item => item.data);

    if (!selected.length) {

        showToast("Unable to load the selected worksheets.");
        return;

    }

    const workfrontContent =
        AppState.workbook?.workfront_content || {};

    const offer =
        serializeWorkfrontContent(workfrontContent);

    const context =
        `Selected worksheets: ${sheetNames.join(", ")}`;

    const defaultInstructions = selected
        .map(item =>
            `### ${item.name}\n${item.data.sheet_prompt || "No configured rules."}`
        )
        .join("\n\n");
    const selectionKey = sheetNames.join("\u001f");
    AppState.originalSheetPrompts[selectionKey] = defaultInstructions;
    const instructions =
        AppState.sessionPromptOverrides[selectionKey] ||
        defaultInstructions;

    AppState.prompt.offer = offer;
    AppState.prompt.context = context;
    AppState.prompt.sheet = instructions;

    UI.offer.value = offer;
    renderWorkfrontContent(workfrontContent);
    UI.context.value = context;
    UI.sheetPrompt.value = instructions;
    renderSheetInstructionSummary(selected);

    updatePromptStatus("offer", offer ? "ready" : "error");
    updatePromptStatus("workbook", context ? "ready" : "error");
    updatePromptStatus("sheet", instructions ? "ready" : "error");

    const attachmentReady =
        await createTemporaryWorkbook(sheetNames);

    if (!attachmentReady) {

        clearGeneratedPrompt();
        updatePromptBuilderActivity(
            "Unable to prepare temporary workbook",
            "danger"
        );
        return;

    }

    regeneratePrompt();
    saveDraft();

    if (hasCompletePromptData()) {

        setWorkflowStep(5);

    }

    updateAIStatus("Prompt Builder Ready");
    showToast(`${selected.length} worksheet${selected.length === 1 ? "" : "s"} loaded`);

}

function renderSheetInstructionSummary(selectedSheets) {

    if (!UI.sheetInstructionSummary) return;
    UI.sheetInstructionSummary.replaceChildren();

    const templateNames = [
        ...new Set(selectedSheets.map(item => item.data.validation_template))
    ].filter(Boolean);
    const worksheetTypes = [
        ...new Set(selectedSheets.map(item => item.data.worksheet_type))
    ].filter(Boolean);

    UI.sheetTemplateName.textContent = templateNames.join(", ") || "Generic Workbook Validation";
    UI.sheetWorksheetType.textContent = worksheetTypes.join(", ") || "Generic Workbook";
    UI.sheetInstructionsModalSheetName.textContent =
        selectedSheets.map(item => item.name).join(", ");
    UI.sheetInstructionsModalTemplateName.textContent =
        UI.sheetTemplateName.textContent;
    UI.sheetInstructionsDetails?.classList.remove("d-none");
    UI.sheetHeaderActions?.classList.remove("d-none");
    if (UI.openSheetInstructionsButton)
        UI.openSheetInstructionsButton.disabled = false;
    const editButton = document.getElementById("editSheetBtn");
    if (editButton) editButton.disabled = false;
    if (UI.sheetInstructionsCollapse && window.bootstrap)
        bootstrap.Collapse.getOrCreateInstance(
            UI.sheetInstructionsCollapse,
            { toggle: false }
        ).hide();

    const summaries = selectedSheets
        .flatMap(item => item.data.validation_summary || [])
        .filter((summary, index, all) => all.indexOf(summary) === index)
        .slice(0, 5);

    summaries.forEach(summary => {
        const item = document.createElement("li");
        item.textContent = summary;
        UI.sheetInstructionSummary.appendChild(item);
    });

}

function serializeWorkfrontContent(content) {

    const serialized =
        Object.entries(content || {})
        .map(([column, value]) =>
            `${formatWorkfrontLabel(column)}: ${
                value === null ||
                value === undefined ||
                String(value).trim() === ""
                    ? "N/A"
                    : String(value)
            }`
        )
        .join("\n");

    return serialized || "N/A";

}

function formatWorkfrontLabel(column) {

    return String(column)
        .replaceAll("_", " ")
        .toLowerCase()
        .replace(
            /\b\w/g,
            character => character.toUpperCase()
        );

}

function renderWorkfrontContent(content) {

    if (!UI.workfrontContentFields) return;
    UI.workfrontContentFields.replaceChildren();

    const entries =
        Object.entries(content || {});

    if (!entries.length) {

        const empty = document.createElement("div");
        empty.className = "workfront-content-empty";
        empty.textContent = "No Workfront content available.";
        UI.workfrontContentFields.appendChild(empty);
        return;

    }

    entries.forEach(([column, value]) => {

        const row = document.createElement("div");
        row.className = "workfront-content-row";

        const label = document.createElement("span");
        label.className = "workfront-content-label";
        label.textContent =
            formatWorkfrontLabel(column);

        const fieldValue = document.createElement("span");
        fieldValue.className = "workfront-content-value";
        fieldValue.textContent =
            value === null ||
            value === undefined ||
            String(value).trim() === ""
                ? "N/A"
                : String(value);

        row.append(label, fieldValue);
        UI.workfrontContentFields.appendChild(row);

    });

}

async function createTemporaryWorkbook(sheetNames) {

    const sessionId =
        AppState.workbook?.workbook_session_id;

    if (!sessionId || !sheetNames.length)
        return false;

    updatePromptBuilderActivity(
        "Building temporary workbook...",
        "warning",
        true
    );

    try {

        const response = await fetch(
            "/temporary_workbook",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    workbook_session_id: sessionId,
                    selected_sheets: sheetNames
                })
            }
        );
        const attachment =
            await response.json();

        if (!response.ok)
            throw new Error(
                attachment.error ||
                "Unable to create temporary workbook."
            );

        AppState.temporaryWorkbook = attachment;
        renderTemporaryWorkbookAttachment();
        return true;

    }
    catch (error) {

        console.error(error);
        showToast(error.message);
        clearTemporaryWorkbookAttachment();
        return false;

    }

}

function renderTemporaryWorkbookAttachment() {

    const attachment =
        AppState.temporaryWorkbook;

    if (!attachment) {

        clearTemporaryWorkbookAttachment();
        return;

    }

    if (UI.temporaryWorkbookName)
        UI.temporaryWorkbookName.textContent = attachment.filename;
    if (UI.temporaryWorkbookSheets)
        UI.temporaryWorkbookSheets.textContent =
            `${attachment.sheets.length} worksheet${attachment.sheets.length === 1 ? "" : "s"} · ${attachment.sheets.join(", ")}`;
    if (UI.temporaryWorkbookSize)
        UI.temporaryWorkbookSize.textContent = formatFileSize(attachment.size);

    updatePromptAttachments();
    updateReadyHighlights();

}

function clearTemporaryWorkbookAttachment() {

    AppState.temporaryWorkbook = null;
    AppState.readyHighlightKey = "";
    UI.temporaryWorkbookAttachment?.classList.add(
        "d-none"
    );
    UI.temporaryWorkbookAttachment?.classList.remove(
        "ready-state",
        "attention-pulse"
    );

}

function updatePromptAttachments() {

    const prompt =
        AppState.prompt.final || "";

    if (UI.generatedPromptFileSize)
        UI.generatedPromptFileSize.textContent =
            formatFileSize(
                new Blob([prompt]).size
            );

    UI.temporaryWorkbookAttachment?.classList.toggle(
        "d-none",
        !(
            prompt &&
            AppState.temporaryWorkbook
        )
    );

}

function formatFileSize(bytes) {

    if (!Number.isFinite(Number(bytes)))
        return "";
    if (bytes < 1024)
        return `${bytes} B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;

}

/* ============================================================
   LOAD SHEET DATA
============================================================ */

function loadSelectedSheet(sheetName) {

    return loadSelectedSheets([sheetName]);

    const sheet =
        AppState.workbook
            ?.sheet_data?.[sheetName];

    if (!sheet) {

        showToast(
            "Unable to load worksheet."
        );

        return;

    }

    /* Store */

    AppState.prompt.offer =
        sheet.offer_description || "";

    AppState.prompt.context =
        sheet.workbook_context || "";

    AppState.prompt.sheet =
        sheet.sheet_prompt || "";

    AppState.prompt.final =
        sheet.generated_prompt || "";

    /* Populate UI */

    UI.offer.value =
        AppState.prompt.offer;

    UI.context.value =
        AppState.prompt.context;

    UI.sheetPrompt.value =
        AppState.prompt.sheet;

    UI.finalPrompt.value =
        AppState.prompt.final;

    /* Update Status */

    updatePromptStatus(
        "offer",
        "ready"
    );

    updatePromptStatus(
        "workbook",
        "ready"
    );

    updatePromptStatus(
        "sheet",
        "ready"
    );

    updatePreview();

    saveDraft();

    if (hasCompletePromptData()) {

        setWorkflowStep(5);

    }

    else {

        updatePromptBuilderActivity(
            "Prompt Data Incomplete",
            "danger"
        );

    }

    updateAIStatus(
        "Prompt Builder Ready"
    );

    showToast(
        `${sheetName} loaded`
    );

}

/* ============================================================
   LOAD FIRST SHEET
============================================================ */

function loadDefaultSheet() {

    if (!UI.sheetSelector)
        return;

    if (
        UI.sheetSelector.options.length === 0
    )
        return;

    UI.sheetSelector.options[0].selected = true;

    handleSheetSelection();

}

/* ============================================================
   REFRESH CURRENT SHEET
============================================================ */

function refreshCurrentSheet() {

    if (!AppState.selectedSheets.length)
        return;

    loadSelectedSheets(
        AppState.selectedSheets
    );

}

/* ============================================================
   CLEAR WORKBOOK
============================================================ */

function clearWorkbook() {

    AppState.workbook = null;

    AppState.selectedSheet = "";

    AppState.selectedSheets = [];
    AppState.worksheetSelectionOrder = [];

    AppState.workbookName = "";

    AppState.workbookType = "";

    UI.workbookDetailsStrip?.classList.add("d-none");

    UI.sheetSelectorGroup?.classList.add("d-none");

    if (UI.workbookName)
        UI.workbookName.textContent =
            "Not Loaded";

    if (UI.workbookSource) {

        UI.workbookSource.textContent = "-";
        UI.workbookSource.className =
            "badge bg-secondary";

    }

    if (UI.workbookType)
        UI.workbookType.textContent =
            "-";

    if (UI.sheetCount)
        UI.sheetCount.textContent =
            "0";

    resetSheetSelector();

    clearPromptBuilder();
    showSheetInstructionsEmptyState();
    renderWorkbookContent([]);
    clearTemporaryWorkbookAttachment();

    updateAIStatus(
        "Ready"
    );

    updatePIIBadge(false);

    setWorkflowStep(1);

}

/******************************************************************
 * 03_promptBuilder.js
 * Part 3A
 * Prompt Builder
 * Edit Mode
 ******************************************************************/

"use strict";

/* ============================================================
   EDIT STATE
============================================================ */

const EditState = {

    offer: false,

    workbook: false,

    sheet: false

};

/* ============================================================
   REGISTER EDIT EVENTS
============================================================ */

function registerPromptBuilderEvents() {

    UI.viewFullSheetInstructionsButton?.addEventListener(
        "click",
        () => openSheetInstructionsModal(false)
    );

    UI.modalEditSheetInstructionsButton?.addEventListener(
        "click",
        () => setSheetInstructionsEditMode(true)
    );

    UI.copySheetInstructionsButton?.addEventListener(
        "click",
        () => copyToClipboard(
            UI.sheetPrompt?.value || "",
            "Sheet instructions copied."
        )
    );

    UI.saveSheetInstructionsButton?.addEventListener(
        "click",
        saveSheetInstructionsForSession
    );

    UI.resetSheetInstructionsButton?.addEventListener(
        "click",
        resetSheetInstructionsToOriginal
    );

    document
        .getElementById("editOfferBtn")
        ?.addEventListener(
            "click",
            () => toggleEditor("offer")
        );

    document
        .getElementById("editWorkbookBtn")
        ?.addEventListener(
            "click",
            () => toggleEditor("workbook")
        );

    document
        .getElementById("editSheetBtn")
        ?.addEventListener(
            "click",
            () => openSheetInstructionsModal(true)
        );

}

function showSheetInstructionsEmptyState() {

    UI.sheetInstructionsDetails?.classList.add("d-none");
    UI.sheetHeaderActions?.classList.add("d-none");
    if (UI.sheetInstructionsCollapse && window.bootstrap)
        bootstrap.Collapse.getOrCreateInstance(
            UI.sheetInstructionsCollapse,
            { toggle: false }
        ).hide();
    UI.sheetInstructionSummary?.replaceChildren();
    if (UI.sheetTemplateName) UI.sheetTemplateName.textContent = "-";
    if (UI.sheetWorksheetType) UI.sheetWorksheetType.textContent = "-";
    if (UI.openSheetInstructionsButton)
        UI.openSheetInstructionsButton.disabled = true;
    const editButton = document.getElementById("editSheetBtn");
    if (editButton) editButton.disabled = true;

}

function openSheetInstructionsModal(edit = false) {

    if (!AppState.selectedSheets.length || !UI.sheetPrompt?.value) {
        showToast("Upload a workbook and select a worksheet first.");
        return;
    }

    const selectionKey = AppState.selectedSheets.join("\u001f");
    UI.sheetPrompt.value =
        AppState.sessionPromptOverrides[selectionKey] ||
        AppState.originalSheetPrompts[selectionKey] ||
        UI.sheetPrompt.value;
    setSheetInstructionsEditMode(edit);
    if (UI.resetSheetInstructionsButton)
        UI.resetSheetInstructionsButton.disabled =
            !AppState.sessionPromptOverrides[selectionKey];
    BootstrapUI.sheetInstructionsModal?.show();

}

function setSheetInstructionsEditMode(editing) {

    EditState.sheet = editing;
    UI.sheetPrompt.readOnly = !editing;
    UI.sheetPrompt.classList.toggle("border-primary", editing);
    UI.modalEditSheetInstructionsButton?.classList.toggle("d-none", editing);
    if (UI.saveSheetInstructionsButton)
        UI.saveSheetInstructionsButton.disabled = !editing;
    if (editing) UI.sheetPrompt.focus();

}

function saveSheetInstructionsForSession() {

    if (!AppState.selectedSheets.length) return;
    const selectionKey = AppState.selectedSheets.join("\u001f");
    AppState.sessionPromptOverrides[selectionKey] = UI.sheetPrompt.value;
    AppState.prompt.sheet = UI.sheetPrompt.value;
    setSheetInstructionsEditMode(false);
    regeneratePrompt();
    updatePromptStatus("sheet", "ready");
    showToast("Instructions saved for this session.");

    if (UI.resetSheetInstructionsButton)
        UI.resetSheetInstructionsButton.disabled = false;

}

function resetSheetInstructionsToOriginal() {

    if (!AppState.selectedSheets.length) return;
    const selectionKey = AppState.selectedSheets.join("\u001f");
    const original = AppState.originalSheetPrompts[selectionKey];
    if (!original) return;

    delete AppState.sessionPromptOverrides[selectionKey];
    UI.sheetPrompt.value = original;
    AppState.prompt.sheet = original;
    setSheetInstructionsEditMode(false);
    regeneratePrompt();
    updatePromptStatus("sheet", "ready");
    if (UI.resetSheetInstructionsButton)
        UI.resetSheetInstructionsButton.disabled = true;
    showToast("Original template instructions restored.");

}

/* ============================================================
   TOGGLE EDITOR
============================================================ */

function toggleEditor(section) {

    switch (section) {

        case "offer":

            toggleTextarea(

                UI.offer,

                "offer",

                "editOfferBtn"

            );

            break;

        case "workbook":

            toggleTextarea(

                UI.context,

                "workbook",

                "editWorkbookBtn"

            );

            break;

        case "sheet":

            toggleTextarea(

                UI.sheetPrompt,

                "sheet",

                "editSheetBtn"

            );

            break;

    }

}

/* ============================================================
   GENERIC TOGGLE
============================================================ */

function toggleTextarea(

    textarea,

    key,

    buttonId

) {

    if (!textarea) return;

    const button =

        document.getElementById(buttonId);

    EditState[key] =

        !EditState[key];

    textarea.readOnly =

        !EditState[key];

    textarea.classList.toggle(

        "border-primary",

        EditState[key]

    );

    if (EditState[key]) {

        button.innerHTML = `

            <i class="bi bi-check-lg"></i>

            Save

        `;

        textarea.focus();

        updatePromptStatus(

            key,

            "editing"

        );

        expandSection(textarea);

    }

    else {

        button.innerHTML = `

            <i class="bi bi-pencil"></i>

            Edit

        `;

        updatePromptStatus(

            key,

            "ready"

        );

        regeneratePrompt();

        saveDraft();

        showToast(

            "Changes saved."

        );

    }

}

/******************************************************************
 * Part 3B
 * Auto Save
 * Dirty Tracking
 * Accordion
 * Live Prompt Refresh
 ******************************************************************/

/* ============================================================
   AUTO SAVE TIMERS
============================================================ */

const AutoSave = {

    timers: {}

};

/* ============================================================
   REGISTER INPUT EVENTS
============================================================ */

function registerPromptInputEvents() {

    [
        UI.offer,
        UI.context,
        UI.sheetPrompt
    ].forEach(element => {

        if (!element) return;

        element.addEventListener(

            "input",

            handlePromptInput

        );

    });

}

/* ============================================================
   INPUT EVENT
============================================================ */

function handlePromptInput(event) {

    AppState.dirty = true;

    const textarea = event.target;

    let section = "offer";

    if (textarea === UI.context)
        section = "workbook";

    if (textarea === UI.sheetPrompt)
        section = "sheet";

    if (section === "sheet") {
        if (UI.saveSheetInstructionsButton)
            UI.saveSheetInstructionsButton.disabled = false;
        if (UI.resetSheetInstructionsButton)
            UI.resetSheetInstructionsButton.disabled = false;
        updatePromptStatus("sheet", "editing");
        return;
    }

    updatePromptStatus(
        section,
        "editing"
    );

    debounceSave(section);

}

/* ============================================================
   DEBOUNCE SAVE
============================================================ */

function debounceSave(section) {

    clearTimeout(
        AutoSave.timers[section]
    );

    AutoSave.timers[section] =
        setTimeout(() => {

            regeneratePrompt();

            saveDraft();

            AppState.dirty = false;

            updatePromptStatus(
                section,
                "ready"
            );

        }, 500);

}

/* ============================================================
   EXPAND CURRENT SECTION
============================================================ */

function expandSection(textarea) {

    const collapse =
        textarea.closest(".collapse");

    if (!collapse)
        return;

    document
        .querySelectorAll(
            ".prompt-builder-card .prompt-section .collapse.show"
        )
        .forEach(openSection => {

            if (openSection === collapse) return;

            bootstrap.Collapse
                .getOrCreateInstance(
                    openSection,
                    { toggle: false }
                )
                .hide();

        });

    bootstrap
        .Collapse
        .getOrCreateInstance(
            collapse,
            { toggle: false }
        )
        .show();

    const icon =
        collapse
            .closest(".prompt-section")
            ?.querySelector(
                ".accordion-toggle i"
            );

    if (icon) {

        icon.className =
            "bi bi-chevron-down";

    }

}

/* ============================================================
   COLLAPSE ICONS
============================================================ */

function initializeAccordions() {

    document
        .querySelectorAll(".collapse")
        .forEach(section => {

            section.addEventListener(

                "shown.bs.collapse",

                () => {

                    document
                        .querySelectorAll(
                            ".prompt-section.active-section"
                        )
                        .forEach(card => {

                            if (
                                card !==
                                section.closest(".prompt-section")
                            ) {

                                card.classList.remove(
                                    "active-section"
                                );

                            }

                        });

                    section
                        .closest(".prompt-section")
                        ?.classList.add("active-section");

                    const icon =
                        section
                            .closest(".prompt-section")
                            ?.querySelector(
                                ".accordion-toggle i"
                            );

                    if (icon)
                        icon.className =
                            "bi bi-chevron-down";

                }

            );

            section.addEventListener(

                "hidden.bs.collapse",

                () => {

                    section
                        .closest(".prompt-section")
                        ?.classList.remove("active-section");

                    const icon =
                        section
                            .closest(".prompt-section")
                            ?.querySelector(
                                ".accordion-toggle i"
                            );

                    if (icon)
                        icon.className =
                            "bi bi-chevron-right";

                }

            );

        });

}

/* ============================================================
   RESET EDIT MODE
============================================================ */

function resetEditors() {

    EditState.offer = false;
    EditState.workbook = false;
    EditState.sheet = false;

    UI.offer.readOnly = true;
    UI.context.readOnly = true;
    UI.sheetPrompt.readOnly = true;
    UI.modalEditSheetInstructionsButton?.classList.remove("d-none");
    if (UI.saveSheetInstructionsButton)
        UI.saveSheetInstructionsButton.disabled = true;

}

/* ============================================================
   KEYBOARD SHORTCUTS
============================================================ */

document.addEventListener(

    "keydown",

    event => {

        /* CTRL + S */

        if (

            event.ctrlKey &&

            event.key.toLowerCase() === "s"

        ) {

            event.preventDefault();

            regeneratePrompt();

            saveDraft();

            showToast(
                "Draft Saved"
            );

        }

        /* CTRL + ENTER */

        if (

            event.ctrlKey &&

            event.key === "Enter"

        ) {

            event.preventDefault();

            regeneratePrompt();

            showToast(
                "Prompt Updated"
            );

        }

    }

);

/* ============================================================
   INITIALIZE PROMPT BUILDER
============================================================ */

function initializePromptBuilder() {

    registerPromptBuilderEvents();

    registerPromptInputEvents();

    initializeAccordions();

    resetEditors();

}

/******************************************************************
 * 04_promptGeneration.js
 * Part 4A
 * Prompt Generation Engine
 ******************************************************************/

"use strict";

/* ============================================================
   REGENERATE PROMPT
============================================================ */

function hasCompletePromptData() {

    return Boolean(
        AppState.selectedSheets.length &&
        AppState.temporaryWorkbook &&
        UI.offer?.value.trim() &&
        UI.sheetPrompt?.value.trim()
    );

}

function updateGeneratedPromptStatus(ready) {

    if (UI.generatedPromptStatus) {

        UI.generatedPromptStatus.className =
            `compact-status text-${ready ? "success" : "secondary"}`;

        UI.generatedPromptStatus.textContent =
            "●";

        UI.generatedPromptStatus.title =
            ready ? "Ready" : "Waiting";

        UI.generatedPromptStatus.textContent =
            ready ? "● Ready" : "● Waiting";

        UI.generatedPromptStatus.setAttribute(
            "aria-label",
            ready ? "Ready" : "Waiting"
        );

        UI.generatedPromptStatus.textContent =
            ready
                ? "✓ Final Prompt Ready"
                : "● Waiting";

    }

    updatePromptReadiness(
        ready ? "safety-pending" : "waiting"
    );

    updateGPTAvailability(ready);

    const safetyCard =
        document.querySelector(
            ".prompt-safety-card"
        );

    safetyCard?.classList.toggle(
        "safety-disabled",
        false
    );

    const safetyToggle =
        safetyCard?.querySelector(
            '[data-bs-target="#safetyCollapse"]'
        );

    if (safetyToggle) {

        safetyToggle.disabled = false;
        safetyToggle.setAttribute(
            "aria-disabled",
            "false"
        );

    }

    if (UI.previewButton) {

        UI.previewButton.disabled = !ready;

    }

    if (
        ready &&
        AppState.promptSafe &&
        UI.gptIframe &&
        UI.gptIframe.getAttribute("src") === "about:blank"
    ) {

        UI.gptIframe.src = "https://chatgpt.com";

    }

    updateReadyHighlights();

}

function updateReadyHighlights() {

    const promptReady =
        Boolean(
            AppState.prompt.final &&
            hasCompletePromptData()
        );
    const attachmentReady =
        Boolean(AppState.temporaryWorkbook);

    UI.generatedPromptCard?.classList.toggle(
        "ready-state",
        promptReady
    );
    UI.temporaryWorkbookAttachment?.classList.toggle(
        "ready-state",
        attachmentReady
    );

    if (!promptReady || !attachmentReady)
        return;

    const readyKey =
        `${AppState.temporaryWorkbook.attachment_id}:${
            AppState.temporaryWorkbook.sheets.join("|")
        }`;

    if (AppState.readyHighlightKey === readyKey)
        return;

    AppState.readyHighlightKey = readyKey;

    [
        UI.generatedPromptCard,
        UI.temporaryWorkbookAttachment
    ].forEach(element => {

        element?.classList.remove("attention-pulse");
        void element?.offsetWidth;
        element?.classList.add("attention-pulse");

    });

    window.clearTimeout(updateReadyHighlights.timer);
    updateReadyHighlights.timer =
        window.setTimeout(
            () => {

                UI.generatedPromptCard?.classList.remove(
                    "attention-pulse"
                );
                UI.temporaryWorkbookAttachment?.classList.remove(
                    "attention-pulse"
                );

            },
            4200
        );

}

function updateGPTAvailability(promptReady) {

    const enabled =
        Boolean(promptReady && AppState.promptSafe);

    UI.gptWorkspaceEmpty?.classList.toggle(
        "d-none",
        enabled
    );

    UI.gptIframe?.classList.toggle(
        "d-none",
        !enabled
    );

    UI.copyButton?.classList.toggle(
        "d-none",
        !enabled
    );

    if (
        enabled &&
        UI.gptIframe?.getAttribute("src") === "about:blank"
    ) {

        UI.gptIframe.src = "https://chatgpt.com";

    }

}

function updatePromptReadiness(state) {

    return state;

}

function regeneratePrompt() {

    const offer =
        UI.offer?.value.trim() || "";

    const context =
        UI.context?.value.trim() || "";

    const instructions =
        UI.sheetPrompt?.value.trim() || "";

    AppState.prompt.offer = offer;
    AppState.prompt.context = context;
    AppState.prompt.sheet = instructions;

    const ready = hasCompletePromptData();

    const unmaskedPrompt = ready
        ? buildPrompt(
            offer,
            instructions
        )
        : "";

    const maskingResult =
        applyAutomaticMasking(unmaskedPrompt);

    const prompt = maskingResult.text;
    AppState.maskingSummary = maskingResult.summary;
    AppState.prompt.final = prompt;
    updatePromptAttachments();

    if (UI.finalPrompt) {

        UI.finalPrompt.value = prompt;

    }

    syncPromptPreview();

    updatePromptMetrics();

    updateGeneratedPromptStatus(ready);

    resetPromptSafety();

}

function applyAutomaticMasking(text) {

    const summary = [];
    const patterns = [
        {
            type: "Credit Card",
            regex: /(?<!\d)(?:\d{16}|\d{4}-\d{4}-\d{4}-\d{4}|\d{4}\.\d{4}\.\d{4}\.\d{4}|\d{4}\s\d{4}\s\d{4}\s\d{4})(?!\d)/g,
            masked: "[MASKED CREDIT CARD]"
        },
        {
            type: "SSN",
            regex: /(?<!\d)(?:\d{3}-\d{2}-\d{4}|\d{3}\.\d{2}\.\d{4}|\d{3}\s\d{2}\s\d{4})(?!\d)/g,
            masked: "[MASKED SSN]"
        }
    ];

    let maskedText = text;

    patterns.forEach(({ type, regex, masked }) => {

        maskedText = maskedText.replace(regex, original => {

            summary.push({
                type,
                original,
                masked
            });

            return masked;

        });

    });

    return { text: maskedText, summary };

}

function renderMaskingSummary() {

    const creditCardCount =
        AppState.maskingSummary.filter(
            item => item.type === "Credit Card"
        ).length;
    const ssnCount =
        AppState.maskingSummary.filter(
            item => item.type === "SSN"
        ).length;

    setPromptSafetyState(
        AppState.workbook && AppState.prompt.final
            ? "complete"
            : AppState.workbook
                ? "scanning"
                : "waiting",
        creditCardCount,
        ssnCount
    );

    if (
        !UI.maskingSummary ||
        !UI.maskingSummaryCount ||
        !UI.maskingSummaryList
    ) return;

    UI.maskingSummaryCount.textContent =
        AppState.maskingSummary.length;
    UI.maskingSummaryList.replaceChildren();

    if (UI.creditCardMaskStatus)
        UI.creditCardMaskStatus.textContent =
            `${creditCardCount} masked`;
    if (UI.ssnMaskStatus)
        UI.ssnMaskStatus.textContent =
            `${ssnCount} masked`;

    AppState.maskingSummary.forEach(item => {

        const row = document.createElement("div");
        row.className = "masking-summary-row";

        const type = document.createElement("span");
        type.className = "badge bg-secondary";
        type.textContent = item.type;

        const values = document.createElement("code");
        values.textContent =
            `${item.original} \u2192 ${item.masked}`;

        row.append(type, values);
        UI.maskingSummaryList.appendChild(row);

    });

    UI.maskingSummary.classList.remove("d-none");

}

/* ============================================================
   BUILD PROMPT
============================================================ */

function buildPrompt(

    offer,

    instructions

) {

    const attachment =
        AppState.temporaryWorkbook;

    const worksheetSections =
        AppState.selectedSheets.map(name => {

            const rows =
                AppState.workbook
                    ?.sheet_data?.[name]
                    ?.preview_rows || [];

            const content =
                rows
                    .map(row =>
                        row
                            .map(value =>
                                String(
                                    value && typeof value === "object"
                                        ? value.value ?? ""
                                        : value ?? ""
                                )
                            )
                            .join("\t")
                    )
                    .join("\n");

            return [
                `## Worksheet: ${name}`,
                "",
                content || "(Worksheet is empty.)"
            ].join("\n");

        }).join(
            "\n\n----------------------------------------\n\n"
        );

    return [

        "# Generated Prompt.txt",

        "",

        "========================================",

        "",

        "## Workfront Content",

        offer || "Not Available",

        "",

        "========================================",

        "",

        "## Sheet Instructions",

        instructions || "Not Available",

        "",

        "========================================",

        "",

        "# Selected Worksheet Content",

        "",

        worksheetSections ||
            "(No worksheet content selected.)",

        "",

        "========================================",

        "",

        `Selected workbook: ${attachment?.filename || "temporary workbook"}`

    ].join("\n");

}

/* ============================================================
   SYNC PREVIEW
============================================================ */

function syncPromptPreview() {

    if (

        UI.previewArea &&

        UI.finalPrompt

    ) {

        UI.previewArea.value =

            UI.finalPrompt.value;

    }

}

/* ============================================================
   PROMPT METRICS
============================================================ */

function updatePromptMetrics() {

    const prompt =

        UI.finalPrompt?.value || "";

    AppState.prompt.characters =

        prompt.length;

    AppState.prompt.words =

        prompt

            .trim()

            .split(/\s+/)

            .filter(Boolean)

            .length;

}

/* ============================================================
   AUTO REGENERATE
============================================================ */

function refreshGeneratedPrompt() {

    regeneratePrompt();

    saveDraft();

}

/* ============================================================
   CLEAR GENERATED PROMPT
============================================================ */

function clearGeneratedPrompt() {

    AppState.prompt.final = "";
    AppState.maskingSummary = [];

    if (UI.finalPrompt)

        UI.finalPrompt.value = "";

    if (UI.previewArea)

        UI.previewArea.value = "";

    updateGeneratedPromptStatus(false);
    updatePromptAttachments();

    resetPromptSafety();

}

/******************************************************************
 * Part 4B
 * Preview
 * Copy
 * Download
 * GPT Workspace
 ******************************************************************/

"use strict";

/* ============================================================
   SHOW PROMPT PREVIEW
============================================================ */

async function showPromptPreview() {

    regeneratePrompt();

    const safe = await validatePrompt();

    if (!safe) return;

    syncPromptPreview();

    BootstrapUI.previewModal?.show();

    setWorkflowStep(6);

    updateAIStatus("GPT Ready");

}

/* ============================================================
   CLOSE PREVIEW
============================================================ */

function closePromptPreview() {

    BootstrapUI.previewModal?.hide();

}

/* ============================================================
   COPY GENERATED PROMPT
============================================================ */

async function copyPrompt() {

    regeneratePrompt();

    const safe = await validatePrompt();

    if (!safe) return;

    const copied = await copyToClipboard(

        UI.finalPrompt.value,
        null

    );

    if (copied) {

        BootstrapUI.copySafetyReminderModal?.show();
        updateAIStatus("Prompt Copied");

    }

}

/* ============================================================
   COPY PREVIEW
============================================================ */

async function copyPreviewPrompt() {

    const copied = await copyToClipboard(

        UI.previewArea.value,
        null

    );

    if (copied)
        BootstrapUI.copySafetyReminderModal?.show();

}

/* ============================================================
   DOWNLOAD PROMPT
============================================================ */

function downloadPrompt() {

    regeneratePrompt();

    const blob = new Blob(

        [UI.finalPrompt.value],

        {

            type: "text/plain"

        }

    );

    const url =

        URL.createObjectURL(blob);

    const link =

        document.createElement("a");

    link.href = url;

    link.download =

        "Workbook_AI_Prompt.txt";

    link.click();

    URL.revokeObjectURL(url);

}

/* ============================================================
   OPEN GPT
============================================================ */

function openGPTWorkspace() {

    const iframe =

        document.getElementById(

            "gptIframe"

        );

    if (iframe) {

        iframe.src =

            "https://chatgpt.com";

        return;

    }

    window.open(

        "https://chatgpt.com",

        "_blank"

    );

}

/* ============================================================
   VALIDATION
============================================================ */

async function validatePrompt() {

    if (

        !UI.finalPrompt ||

        !UI.finalPrompt.value.trim()

    ) {

        showToast(

            "Generate a prompt first."

        );

        return false;

    }

    AppState.promptSafe = true;
    updateGPTAvailability(
        hasCompletePromptData()
    );
    return true;

}

/* ============================================================
   PROMPT SUMMARY
============================================================ */

function promptSummary() {

    return {

        characters:

            AppState.prompt.characters,

        words:

            AppState.prompt.words,

        sheet:

            AppState.selectedSheet,

        workbook:

            AppState.workbookName

    };

}

/* ============================================================
   BUTTON EVENTS
============================================================ */

function registerPromptActions() {

    UI.previewButton?.addEventListener(

        "click",

        showPromptPreview

    );

    UI.copyButton?.addEventListener(

        "click",

        copyPrompt

    );

    UI.copyPreviewButton?.addEventListener(

        "click",

        copyPreviewPrompt

    );

}

/* ============================================================
   INITIALIZE
============================================================ */

function initializePromptGeneration() {

    const actionFooter =
        document.querySelector(
            ".generated-prompt-card > .card-footer"
        );

    const headerRow =
        document.querySelector(
            ".generated-prompt-card > .card-header > .d-flex"
        );

    const actionBar =
        actionFooter?.querySelector(
            ".prompt-action-bar"
        );

    if (actionFooter && actionBar && headerRow) {

        const headerActions =
            document.createElement("div");

        headerActions.className =
            "generated-prompt-header-actions";

        const titleGroup =
            headerRow.firstElementChild;

        if (UI.generatedPromptStatus && titleGroup) {

            titleGroup.classList.add(
                "generated-prompt-title-group"
            );

            titleGroup.appendChild(
                UI.generatedPromptStatus
            );

        }

        actionBar.className =
            "generated-prompt-actions btn-group";

        if (UI.previewButton) {

            UI.previewButton.innerHTML =
                '<i class="bi bi-eye me-1"></i>Preview Prompt';
            UI.previewButton.title = "Preview Prompt";
            UI.previewButton.setAttribute(
                "aria-label",
                "Preview Prompt"
            );

        }

        UI.copyButton.innerHTML =
            '<i class="bi bi-clipboard me-1"></i>Copy Final Prompt';
        UI.copyButton.title = "Copy Final Prompt";
        UI.copyButton.setAttribute(
            "aria-label",
            "Copy Final Prompt"
        );

        headerActions.appendChild(actionBar);
        headerRow.appendChild(headerActions);
        actionFooter.remove();

    }

    registerPromptActions();

    syncPromptPreview();

    updateGeneratedPromptStatus(
        hasCompletePromptData()
    );

    UI.downloadPromptButton?.addEventListener(

        "click",

        downloadPrompt

    );

    resetPromptSafety();

}

/******************************************************************
 * 05_piiWorkflow.js
 * Part 5A
 * PII Scanner
 * Prompt Validation
 ******************************************************************/

"use strict";

/* ============================================================
   PII SCAN
============================================================ */

function resetPromptSafety() {

    AppState.promptSafe =
        Boolean(AppState.prompt.final);

    updateGPTAvailability(
        hasCompletePromptData()
    );

    setBadge(
        UI.promptSafetyStatus,
        AppState.workbook ? "Active" : "Waiting",
        AppState.workbook ? "success" : "secondary"
    );

    if (UI.promptSafetyAlert) {

        UI.promptSafetyAlert.className =
            "alert alert-secondary mt-3 mb-0";

        UI.promptSafetyAlert.innerHTML =
            '<i class="bi bi-shield-exclamation me-2"></i>' +
            "<strong>Prompt Safety Notice:</strong> This tool automatically masks Credit Card and SSN values only. It does not detect or mask other sensitive or confidential information. Please review the generated prompt carefully before copying or sharing it externally.";

    }

    renderMaskingSummary();

}

function setPromptSafetyState(state, creditCardCount = 0, ssnCount = 0) {

    if (!UI.promptSafetyMessage) return;

    const iconClasses = {
        waiting: "bi bi-hourglass",
        scanning: "bi bi-arrow-repeat status-spinner",
        complete: "bi bi-check-circle-fill"
    };

    UI.promptSafetyIcon.className =
        iconClasses[state] || iconClasses.waiting;

    if (state === "scanning") {
        UI.promptSafetyMessage.textContent =
            "Scanning workbook for sensitive information...";
        return;
    }

    if (state === "complete") {
        const total = creditCardCount + ssnCount;
        UI.promptSafetyMessage.textContent = total
            ? `${creditCardCount} Credit Card and ${ssnCount} SSN value${total === 1 ? "" : "s"} detected and masked`
            : "No Credit Card/SSN values detected";
        return;
    }

    UI.promptSafetyMessage.textContent =
        "Waiting for workbook. Upload a workbook to perform PII detection.";

}

function getPromptSections() {

    const sections = {};
    const selectedSheets =
        AppState.selectedSheets.length
            ? AppState.selectedSheets
            : [AppState.selectedSheet].filter(Boolean);

    if (selectedSheets.length) {

        sections[
            `${selectedSheets[0]}::Offer Description`
        ] = UI.offer?.value || "";

    }

    selectedSheets.forEach(name => {

        const sheet =
            AppState.workbook?.sheet_data?.[name];

        if (!sheet) return;

        sections[
            `${name}::Workbook Context`
        ] = sheet.workbook_context || "";

        sections[
            `${name}::Sheet Instructions`
        ] = [
            sheet.sheet_prompt || "",
            sheet.sheet_sample || ""
        ].join("\n\n");

    });

    return sections;

}

async function scanPromptForPII() {

    try {

        showLoading(false);

        setBadge(
            UI.promptSafetyStatus,
            "Validating",
            "warning",
            true
        );

        updateAIStatus("Scanning Prompt...");

        const response = await fetch(

            "/scan_pii",

            {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json"

                },

                body: JSON.stringify({

                    prompt:

                        UI.finalPrompt.value

                })

            }

        );

        const result =
            await response.json();

        hideLoading();

        if (!response.ok) {

            throw new Error(

                result.error ||

                "PII Scan Failed"

            );

        }

        updatePIIInformation(result);

        return !result.has_pii;

    }

    catch (error) {

        hideLoading();

        console.error(error);

        showError(

            error.message

        );

        return false;

    }

}

/* ============================================================
   UPDATE PII STATUS
============================================================ */

function updatePIIInformation(result) {

    AppState.promptSafe = !result.has_pii;
    updateGPTAvailability(
        !result.has_pii && hasCompletePromptData()
    );
    renderMaskingSummary();
    updateAIStatus(
        result.has_pii ? "Masking Required" : "Prompt Safe"
    );

    return;

    if (result.has_pii) {

        UI.piiResult.className =

            "badge bg-danger";

        UI.piiResult.innerHTML =

            `${result.count} PII Found`;

    }

    else {

        UI.piiResult.className =

            "badge bg-success";

        UI.piiResult.innerHTML =

            "No PII Found";

    }

    setBadge(
        UI.promptSafetyStatus,
        result.has_pii
            ? `⚠ PII Detected (${result.count || 0})`
            : "🟢 Safe to Send",
        result.has_pii ? "danger" : "success"
    );

    updatePromptReadiness(
        result.has_pii ? "pii" : "ready"
    );

    updateGPTAvailability(
        hasCompletePromptData()
    );

    if (UI.validationResult) {

        UI.validationResult.className =

            result.has_pii

                ? "badge bg-danger"

                : "badge bg-success";

        UI.validationResult.innerHTML =

            result.has_pii

                ? "Failed"

                : "Passed";

    }

    if (UI.promptSafetyAlert) {

        UI.promptSafetyAlert.className =
            result.has_pii
                ? "alert alert-danger mt-3 mb-0"
                : "alert alert-success mt-3 mb-0";

        UI.promptSafetyAlert.innerHTML =
            result.has_pii
                ? '<i class="bi bi-exclamation-triangle-fill me-2"></i>PII was detected. Remove it before using the prompt.'
                : '<i class="bi bi-check-circle-fill me-2"></i>Only Credit Card and SSN are automatically masked. Review the entire prompt before sending it to ChatGPT.';

    }

    renderPIIFindings();

    if (result.has_pii) {

        const safetyElement =
            document.getElementById("safetyCollapse");

        if (safetyElement && window.bootstrap) {

            bootstrap.Collapse
                .getOrCreateInstance(
                    safetyElement,
                    { toggle: false }
                )
                .show();

        }

        document.querySelector(".prompt-safety-card")
            ?.scrollIntoView({
                behavior: "smooth",
                block: "nearest"
            });

    }

    updateAIStatus(

        result.has_pii

            ? "PII Detected"

            : "Prompt Safe"

    );

}

function renderPIIFindings() {

    if (!UI.piiFindings || !UI.piiReport) return;

    UI.piiFindings.replaceChildren();

    if (!AppState.piiFindings.length) {

        UI.piiReport.classList.add("d-none");
        return;

    }

    AppState.piiFindings.forEach((finding, index) => {

        const row = document.createElement("div");
        row.className = "pii-finding";

        const typeLabel = String(finding.type || "unknown")
            .replaceAll("_", " ")
            .replace(/\b\w/g, character => character.toUpperCase());

        row.innerHTML = `
            <div class="pii-finding-grid">
                <div><small class="text-muted d-block">PII Type</small><strong>${escapeHTML(typeLabel)}</strong></div>
                <div><small class="text-muted d-block">Worksheet</small>${escapeHTML(finding.worksheet || "-")}</div>
                <div><small class="text-muted d-block">Section</small>${escapeHTML(finding.section || "-")}</div>
                <div><small class="text-muted d-block">Masked Preview</small><code>${escapeHTML(finding.masked_preview || "****")}</code></div>
                <div><small class="text-muted d-block">Severity</small><span class="badge bg-${finding.severity === "High" ? "danger" : finding.severity === "Medium" ? "warning text-dark" : "secondary"}">${escapeHTML(finding.severity || "Low")}</span></div>
                <div class="d-flex gap-1">
                    <button class="btn btn-sm btn-outline-primary" data-pii-action="goto" data-index="${index}">Go To</button>
                    <button class="btn btn-sm btn-primary" data-pii-action="mask" data-index="${index}">Mask Selected</button>
                </div>
            </div>
        `;

        UI.piiFindings.appendChild(row);

    });

    UI.piiReport.classList.remove("d-none");

}

function escapeHTML(value) {

    const element = document.createElement("span");
    element.textContent = String(value);
    return element.innerHTML;

}

function sectionTarget(section) {

    const targets = {
        "Offer Description": {
            field: UI.offer,
            collapse: "offerCollapse"
        },
        "Workbook Context": {
            field: UI.context,
            collapse: "workbookCollapse"
        },
        "Sheet Instructions": {
            field: UI.sheetPrompt,
            modal: true
        }
    };

    return targets[section];

}

function goToPIIFinding(finding) {

    if (
        finding.worksheet &&
        UI.sheetSelector &&
        UI.sheetSelector.value !== finding.worksheet
    ) {

        UI.sheetSelector.value = finding.worksheet;
        handleSheetSelection();

    }

    const target = sectionTarget(finding.section);
    if (!target?.field) return;

    if (target.modal)
        openSheetInstructionsModal(true);

    const collapseElement =
        document.getElementById(target.collapse);

    if (collapseElement && window.bootstrap) {

        bootstrap.Collapse
            .getOrCreateInstance(
                collapseElement,
                { toggle: false }
            )
            .show();

    }

    target.field.classList.add("pii-highlight");
    target.field.focus();
    target.field.setSelectionRange(
        finding.start,
        finding.end
    );
    target.field.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

    window.setTimeout(
        () => target.field.classList.remove("pii-highlight"),
        2400
    );

}

function maskFindings(findings) {

    const bySource = {};

    findings.forEach(finding => {

        const key =
            `${finding.worksheet}::${finding.section}`;

        (bySource[key] ||= []).push(finding);

    });

    Object.entries(bySource).forEach(
        ([key, sourceFindings]) => {

            const [worksheet, section] =
                key.split("::");

            const sheet =
                AppState.workbook
                    ?.sheet_data?.[worksheet];

            if (!sheet) return;

            let value =
                section === "Offer Description"
                    ? sheet.offer_description || ""
                    : section === "Workbook Context"
                        ? sheet.workbook_context || ""
                        : [
                            sheet.sheet_prompt || "",
                            sheet.sheet_sample || ""
                        ].join("\n\n");

            sourceFindings
                .sort((left, right) => right.start - left.start)
                .forEach(finding => {

                    value =
                        value.slice(0, finding.start) +
                        "*".repeat(finding.end - finding.start) +
                        value.slice(finding.end);

                });

            if (section === "Offer Description") {

                Object.values(
                    AppState.workbook.sheet_data
                ).forEach(item => {

                    item.offer_description = value;

                });

            }

            else if (section === "Workbook Context") {

                sheet.workbook_context = value;

            }

            else {

                const separator = "\n\n";
                const originalPrompt =
                    sheet.sheet_prompt || "";
                const splitAt =
                    Math.min(
                        originalPrompt.length,
                        value.length
                    );

                sheet.sheet_prompt =
                    value.slice(0, splitAt);
                sheet.sheet_sample =
                    value.slice(
                        splitAt + separator.length
                    );

            }

        }
    );

    loadSelectedSheets(
        AppState.selectedSheets
    );

    scanPromptForPII();

    return;

    const grouped = {};

    findings.forEach(finding => {

        (grouped[finding.section] ||= [])
            .push(finding);

    });

    Object.entries(grouped).forEach(
        ([section, sectionFindings]) => {

            const field =
                sectionTarget(section)?.field;

            if (!field) return;

            let value = field.value;

            sectionFindings
                .sort((left, right) => right.start - left.start)
                .forEach(finding => {

                    value =
                        value.slice(0, finding.start) +
                        "*".repeat(finding.end - finding.start) +
                        value.slice(finding.end);

                });

            field.value = value;

        }
    );

    regeneratePrompt();
    scanPromptForPII();

}

function registerPIIActions() {

    UI.piiFindings?.addEventListener("click", event => {

        const button =
            event.target.closest("[data-pii-action]");

        if (!button) return;

        const finding =
            AppState.piiFindings[
                Number(button.dataset.index)
            ];

        if (!finding) return;

        if (button.dataset.piiAction === "goto") {

            goToPIIFinding(finding);

        }

        if (button.dataset.piiAction === "mask") {

            maskFindings([finding]);

        }

    });

    UI.maskAllPiiButton?.addEventListener(
        "click",
        () => maskFindings([...AppState.piiFindings])
    );

    UI.ignoreAllPiiButton?.addEventListener(
        "click",
        () => {

            AppState.ignorePII = true;
            AppState.promptSafe = true;

            setBadge(
                UI.promptSafetyStatus,
                "PII Ignored",
                "warning"
            );

            UI.piiReport?.classList.add("d-none");

            updatePromptReadiness("ready");

            updateGPTAvailability(
                hasCompletePromptData()
            );

            updateAIStatus("PII Ignored");

        }
    );

}

/* ============================================================
   PROMPT SAFETY
============================================================ */

function isPromptSafe(result) {

    return !result.has_pii;

}

/* ============================================================
   VALIDATION SUMMARY
============================================================ */

function validationSummary(result) {

    return {

        safe:

            !result.has_pii,

        piiCount:

            result.count || 0,

        types:

            result.types || {}

    };

}

/******************************************************************
 * Part 5B
 * Error Handling
 * Application Reset
 * Initialization
 ******************************************************************/

"use strict";

/* ============================================================
   ERROR HANDLER
============================================================ */

function showError(message) {

    console.error(message);

    updateAIStatus("Error");

    showToast(message || "Unexpected error occurred.");

}

/* ============================================================
   RESET APPLICATION
============================================================ */

function resetApplication() {

    cancelWorkbookMonitoring();
    endWorkbookSession();
    BootstrapUI.sheetPreviewModal?.hide();
    BootstrapUI.sheetInstructionsModal?.hide();
    BootstrapUI.previewModal?.hide();

    clearWorkbook();

    clearGeneratedPrompt();

    clearDraft();

    AppState.dirty = false;
    AppState.maskingSummary = [];
    AppState.promptSafe = false;
    AppState.temporaryWorkbook = null;
    AppState.sessionPromptOverrides = {};
    AppState.originalSheetPrompts = {};

    AppState.selectedSheet = "";

    AppState.selectedSheets = [];
    AppState.worksheetSelectionOrder = [];

    AppState.prompt = {

        offer: "",

        context: "",

        sheet: "",

        final: "",

        characters: 0,

        words: 0

    };

    resetEditors();

    if (UI.projectRef) UI.projectRef.value = "";
    if (UI.taskNumber) UI.taskNumber.value = "";
    if (UI.manualWorkbookInput)
        UI.manualWorkbookInput.value = "";
    UI.manualDownloadPanel?.classList.add("d-none");

    if (UI.previewSheetButton)
        UI.previewSheetButton.disabled = true;
    renderMaskingSummary();
    clearTemporaryWorkbookAttachment();
    resetPromptSafety();

    const safetyCollapse =
        document.getElementById("safetyCollapse");
    if (safetyCollapse && window.bootstrap) {

        bootstrap.Collapse
            .getOrCreateInstance(
                safetyCollapse,
                { toggle: false }
            )
            .show();

    }

    updateAIStatus("Ready");

    updatePIIBadge(false);

    showToast("Workspace reset successfully.");

}

function endWorkbookSession() {

    const sessionId =
        AppState.workbook?.workbook_session_id;

    if (!sessionId) return;

    fetch(
        "/workbook_session/end",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                workbook_session_id: sessionId
            })
        }
    ).catch(() => {});

}

/* ============================================================
   ENABLE INPUTS
============================================================ */

function enablePromptBuilder() {

    [

        UI.offer,

        UI.context,

        UI.sheetPrompt,

        UI.finalPrompt

    ].forEach(item => {

        if (item)

            item.disabled = false;

    });

}

/* ============================================================
   DISABLE INPUTS
============================================================ */

function disablePromptBuilder() {

    [

        UI.offer,

        UI.context,

        UI.sheetPrompt,

        UI.finalPrompt

    ].forEach(item => {

        if (item)

            item.disabled = true;

    });

}

/* ============================================================
   GLOBAL ERROR EVENTS
============================================================ */

window.addEventListener(

    "error",

    event => {

        console.error(event.error);

        showError(

            event.message

        );

    }

);

window.addEventListener(

    "unhandledrejection",

    event => {

        console.error(

            event.reason

        );

        showError(

            "Unexpected application error."

        );

    }

);

window.addEventListener("pagehide", () => {

    const sessionId =
        AppState.workbook?.workbook_session_id;
    if (!sessionId) return;

    fetch(
        "/workbook_session/end",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                workbook_session_id: sessionId
            }),
            keepalive: true
        }
    ).catch(() => {});

});

/* ============================================================
   APPLICATION STARTUP
============================================================ */

document.addEventListener(

    "DOMContentLoaded",

    () => {

        initializeApplication();

        initializePromptBuilder();

        initializePromptGeneration();

        disablePromptBuilder();

        updateAIStatus("Ready");

        console.log(

            "Workbook Validation Tool Ready"

        );

    }

);

/* ============================================================
   PUBLIC API
============================================================ */

window.WorkbookApp = {

    fetchWorkbook,

    regeneratePrompt,

    showPromptPreview,

    copyPrompt,

    copyPreviewPrompt,

    refreshCurrentSheet,

    resetApplication,

    scanPromptForPII

};
