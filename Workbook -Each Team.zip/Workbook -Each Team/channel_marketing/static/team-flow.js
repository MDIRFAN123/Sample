"use strict";

const TeamEntry = { team: document.body.dataset.teamApp };
const byId = id => document.getElementById(id);

function showEntry() {
    window.WorkbookApp?.resetApplication();
    byId("legacyWorkspace")?.classList.add("d-none");
    byId("entryFlow")?.classList.remove("d-none");
    byId("flowError").classList.add("d-none");
}

function continueProject() {
    const project = byId("flowProjectRef").value.trim();
    const task = byId("flowTaskNumber").value.trim();
    if (!project || !task) {
        byId("flowError").textContent = "Enter both the project reference number and task number.";
        byId("flowError").classList.remove("d-none");
        return;
    }
    byId("projectRef").value = project;
    byId("taskNumber").value = task;
    byId("entryFlow").classList.add("d-none");
    byId("legacyWorkspace").classList.remove("d-none");
    byId("fetchWorkbookBtn").click();
}

document.addEventListener("DOMContentLoaded", () => {
    byId("selectedTeamLabel").textContent = TeamEntry.team;
    byId("continueProjectBtn").onclick = continueProject;
    document.querySelectorAll("[data-go-home],[data-change-project]").forEach(button => button.onclick = showEntry);
});
